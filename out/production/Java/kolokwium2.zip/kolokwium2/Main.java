package kolokwium2;

import java.io.IOException;
import java.io.PrintStream;

public class Main {
    public static void main(String[] args) throws IOException {
        AdminUnitList aul = new AdminUnitList();
        String filename = "src/lab5/admin-units.csv";

        aul.read(filename);
        aul.fixAll();

        for(int i=0; i<aul.units.size(); i++){
            HtmlGenerator h = new HtmlGenerator();
            h.writeHTML(new PrintStream("src/kolokwium2/files/"+i+".html","UTF-8"));
        }
        HtmlGenerator h = new HtmlGenerator();
        //h.setContent();
        //h.writeHTML(new PrintStream(aul.".html","UTF-8"));
        //url.split("/")
    }
}
