package kolokwium2;

import java.io.PrintStream;

public class HtmlGenerator {
    String content;

    HtmlGenerator(){
        this.setContent("");
    }

    HtmlGenerator(String content){
        this.setContent(content);
    }



    HtmlGenerator setContent(String my_content){
        this.content = my_content;
        return this;
    }

    void writeHTML(PrintStream out){
        out.printf("<a href=\"%s\">Plik</a>\n", content);
    }
}
